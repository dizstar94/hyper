source ~/.bashrc

curl -O ~/prereqs-ubuntu.sh https://hyperledger.github.io/composer/latest/prereqs-ubuntu.sh
chmod u+x ~/prereqs-ubuntu.sh
~/prereqs-ubuntu.sh

chmod u+x ./install-prereqs-ubuntu.sh ./install-dev-env.sh ./start-fab-dev-server.sh



